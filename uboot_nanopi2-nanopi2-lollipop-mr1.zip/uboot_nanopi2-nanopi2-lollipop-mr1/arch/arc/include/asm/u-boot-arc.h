/*
 * Copyright (C) 2014 Synopsys, Inc. All rights reserved.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __ASM_ARC_U_BOOT_ARC_H__
#define __ASM_ARC_U_BOOT_ARC_H__

int arch_early_init_r(void);

#endif	/* __ASM_ARC_U_BOOT_ARC_H__ */
