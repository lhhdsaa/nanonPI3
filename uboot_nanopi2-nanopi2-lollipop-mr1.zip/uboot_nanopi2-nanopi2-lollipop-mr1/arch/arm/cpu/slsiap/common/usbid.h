#define USBD_VID    0x2375
#define USBD_PID    0x4330
#define USBD_5430_PID    0x5430

void CalUSBID(U16 *VID, U16 *PID, U32 ECID);
void GetUSBID(U16 *VID, U16 *PID);
